package partes;

public class AtacanteHombre implements Atacante {

    @Override
    public String cabezazo0fensivo() {
        // TODO Auto-generated method stub
        return "atacante hombre cabezea";
    }

    @Override
    public String gambetear() {
        // TODO Auto-generated method stub
        return "atacante hombre gambeta";
    }

    @Override
    public String patearArco() {
        // TODO Auto-generated method stub
        return "atacante hombre patea";
    }
    
}
