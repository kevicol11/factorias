package partes;

public interface Arquero {
    public String tirarzeIzquieda();
    public String saqueArco();
    public String tirarDerecha();
}
