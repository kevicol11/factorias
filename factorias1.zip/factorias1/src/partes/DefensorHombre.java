package partes;

public class DefensorHombre implements Defensor{

    @Override
    public String barrida() {
        // TODO Auto-generated method stub
        return "defensor hombre hace barrida"; 
    }

    @Override
    public String cabezazoDefensivo() {
        // TODO Auto-generated method stub
        return "defensor hombre cabezea";
    }

    @Override
    public String despeje() {
        // TODO Auto-generated method stub
        return "defensor hombre despeja";
    
    
}
}