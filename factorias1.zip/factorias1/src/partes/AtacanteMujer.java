package partes;

public class AtacanteMujer implements Atacante {

    @Override
    public String cabezazo0fensivo() {
        // TODO Auto-generated method stub
        return "atacante mujer cabezea" ;
    }

    @Override
    public String gambetear() {
        // TODO Auto-generated method stub
        return "atacante mujer gambetea";
    }

    @Override
    public String patearArco() {
        // TODO Auto-generated method stub
        return "atacante mujer patea";
    }
    
}
