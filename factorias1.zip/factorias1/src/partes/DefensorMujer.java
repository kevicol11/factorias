package partes;

public class DefensorMujer implements Defensor{

    @Override
    public String barrida() {
        // TODO Auto-generated method stub
        return "defensor mujer hace barrida";
    }

    @Override
    public String cabezazoDefensivo() {
        // TODO Auto-generated method stub
        return "defensro mujer cabezea";
    }

    @Override
    public String despeje() {
        // TODO Auto-generated method stub
        return "defensor mujer despeja";
    }
    
}
